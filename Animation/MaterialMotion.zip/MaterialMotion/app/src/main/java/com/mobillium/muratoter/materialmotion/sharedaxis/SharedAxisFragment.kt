package com.mobillium.muratoter.materialmotion.sharedaxis

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.transition.MaterialSharedAxis
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentSharedAxisBinding
import com.mobillium.muratoter.materialmotion.sharedaxis.x.SharedAxisXActivity
import com.mobillium.muratoter.materialmotion.sharedaxis.y.SharedAxisYActivity
import com.mobillium.muratoter.materialmotion.sharedaxis.z.SharedAxisZ


class SharedAxisFragment : Fragment(R.layout.fragment_shared_axis) {
    private lateinit var binding: FragmentSharedAxisBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSharedAxisBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterTransition = MaterialSharedAxis(MaterialSharedAxis.X, /* forward= */ true)
        returnTransition = MaterialSharedAxis(MaterialSharedAxis.Y, /* forward= */ false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initUI()
    }

    private fun initUI() {
        binding.cardXAxis.setOnClickListener {
            startActivity(Intent(requireContext(), SharedAxisXActivity::class.java))
        }
        binding.cardYAxis.setOnClickListener {
            startActivity(Intent(requireContext(), SharedAxisYActivity::class.java))
        }
        binding.cardZAxis.setOnClickListener {
            startActivity(Intent(requireContext(), SharedAxisZ::class.java))
        }
    }

}