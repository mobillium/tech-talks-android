package com.mobillium.muratoter.materialmotion.fadethrough

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.ActivityFadeThroughBinding

class FadeThroughActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFadeThroughBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFadeThroughBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.bottomNavigationView.inflateMenu(R.menu.menu_fade_through_navigation)
        val navController = findNavController(R.id.nav_host_fragment)
        NavigationUI.setupWithNavController(
            binding.bottomNavigationView,
            navController,
        )
    }
}