package com.mobillium.muratoter.materialmotion.fadethrough

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.transition.MaterialFadeThrough
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentFadeThroughOneBinding
import com.mobillium.muratoter.materialmotion.fadethrough.FadeThroughSettings.FADE_THROUGH_DURATION


class FadeThroughOneFragment : Fragment(R.layout.fragment_fade_through_one) {
    private lateinit var binding: FragmentFadeThroughOneBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterTransition = MaterialFadeThrough().apply {
            duration = FADE_THROUGH_DURATION
        }
//        exitTransition = MaterialFadeThrough().apply {
//            duration = FADE_THROUGH_DURATION
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFadeThroughOneBinding.inflate(inflater, container, false)
        binding.apply {
            content = contentThroughOneItem
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }
}

val contentThroughOneItem = FadeThroughContent(
    "https://is3-ssl.mzstatic.com/image/thumb/Music123/v4/ca/c7/96/cac7966f-dd10-d016-b146-6d8e8cf8fb70/pr_source.png/1000x1000cc.jpg",
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
)