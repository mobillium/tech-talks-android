package com.mobillium.muratoter.materialmotion.containertransform

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import com.google.android.material.color.MaterialColors
import com.google.android.material.transition.platform.MaterialArcMotion
import com.google.android.material.transition.platform.MaterialContainerTransform
import com.google.android.material.transition.platform.MaterialContainerTransformSharedElementCallback
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.containertransform.ContainerTransformSettings.CONTAINER_TRANSFORM_DURATION
import com.mobillium.muratoter.materialmotion.databinding.ActivityAddBinding

class AddActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        window.requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS)
        binding = ActivityAddBinding.inflate(layoutInflater)
        binding.container.transitionName = "shared_element_end_root"
        setEnterSharedElementCallback(MaterialContainerTransformSharedElementCallback())
        window.sharedElementEnterTransition = buildContainerTransform()
        window.sharedElementReturnTransition = buildContainerTransform()
        setContentView(binding.container)
        super.onCreate(savedInstanceState)

        binding.btnClose.setOnClickListener {
            this.onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun buildContainerTransform() =
        MaterialContainerTransform().apply {
            addTarget(binding.container)
            pathMotion = MaterialArcMotion()
            duration = CONTAINER_TRANSFORM_DURATION
            interpolator = FastOutSlowInInterpolator()
            fadeMode = MaterialContainerTransform.FADE_MODE_IN
        }
}