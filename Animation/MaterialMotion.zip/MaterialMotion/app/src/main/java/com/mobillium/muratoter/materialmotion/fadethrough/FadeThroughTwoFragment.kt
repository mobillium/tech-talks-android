package com.mobillium.muratoter.materialmotion.fadethrough

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.transition.MaterialFadeThrough
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentFadeThroughTwoBinding


class FadeThroughTwoFragment : Fragment(R.layout.fragment_fade_through_two) {
    private lateinit var binding: FragmentFadeThroughTwoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterTransition = MaterialFadeThrough().apply {
            duration = FadeThroughSettings.FADE_THROUGH_DURATION
        }
        exitTransition = MaterialFadeThrough().apply {
            duration = FadeThroughSettings.FADE_THROUGH_DURATION
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFadeThroughTwoBinding.inflate(inflater, container, false)
        binding.apply {
            content = contentThroughTwoItem
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

}

val contentThroughTwoItem = FadeThroughContent(
    "https://img.discogs.com/JQny678Vd6janet-PeNjrlK66z8=/fit-in/600x599/filters:strip_icc():format(jpeg):mode_rgb():quality(90)/discogs-images/R-8489874-1510971569-9261.jpeg.jpg",
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt "
)