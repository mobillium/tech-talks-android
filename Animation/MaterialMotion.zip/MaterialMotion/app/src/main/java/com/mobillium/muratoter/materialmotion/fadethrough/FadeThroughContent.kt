package com.mobillium.muratoter.materialmotion.fadethrough

data class FadeThroughContent(
    val image: String,
    val desc: String
)