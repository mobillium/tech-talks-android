package com.mobillium.muratoter.materialmotion.containertransform

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.Window
import androidx.core.app.ActivityOptionsCompat
import com.google.android.material.transition.platform.MaterialContainerTransformSharedElementCallback
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.ActivityListBinding

class ListActivity : AppCompatActivity(), MyListAdapter.ClickListener {
    private lateinit var binding: ActivityListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        window.requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS) //Enable Activity Transitions. Optionally enable Activity transitions in your theme with <item name=”android:windowActivityTransitions”>true</item>.
        binding = ActivityListBinding.inflate(layoutInflater)
        setExitSharedElementCallback(MaterialContainerTransformSharedElementCallback())
        window.sharedElementsUseOverlay = false // Keep system bars (status bar, navigation bar) persistent throughout the transition.
        setContentView(binding.root)
        super.onCreate(savedInstanceState)

        initUI()
    }

    private fun initUI() {
        binding.run {
            list = ListStore.allItems
            adapter = MyListAdapter(this@ListActivity)
        }

        binding.btnAdd.setOnClickListener {
            navigateToCreate()
        }
    }


    override fun onClick(view: View, item: ListItem) {
        val intent=Intent(this,DetailActivity::class.java)
        val options = ActivityOptionsCompat.makeSceneTransitionAnimation(
            this,
            view,
            item.id.toString(),
        )
        intent.putExtra("item", item)
        startActivity(intent, options.toBundle())
    }

    private fun navigateToCreate() {
        val intent=Intent(this,AddActivity::class.java)
        val options = ActivityOptionsCompat.makeSceneTransitionAnimation(
            this,
            binding.btnAdd,
            "shared_element_end_root",
        )
        startActivity(intent, options.toBundle())

    }
}