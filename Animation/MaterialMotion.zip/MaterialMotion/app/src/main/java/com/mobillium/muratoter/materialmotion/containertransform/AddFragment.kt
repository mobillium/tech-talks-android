package com.mobillium.muratoter.materialmotion.containertransform

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import androidx.navigation.fragment.findNavController
import androidx.transition.Slide
import androidx.transition.TransitionInflater
import com.google.android.material.transition.platform.MaterialArcMotion
import com.google.android.material.transition.platform.MaterialContainerTransform
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentAddBinding


class AddFragment : Fragment(R.layout.fragment_add) {

    private lateinit var binding: FragmentAddBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAddBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        TransitionInflater.from(requireContext()).inflateTransition(android.R.transition.move)

        binding.run {
            enterTransition = MaterialContainerTransform()
                .apply {
                addTarget(binding.root)
//                setAllContainerColors(MaterialColors.getColor(binding.root, R.attr.))
                pathMotion = MaterialArcMotion()
                duration = 500
                interpolator = FastOutSlowInInterpolator()
                fadeMode = MaterialContainerTransform.FADE_MODE_IN
            }
            returnTransition = Slide().apply {
                duration = resources.getInteger(R.integer.motion_duration_medium).toLong()
                addTarget(binding.clAddMain)
            }
        }

        binding.btnClose.setOnClickListener {
            findNavController().popBackStack()
        }
    }
}