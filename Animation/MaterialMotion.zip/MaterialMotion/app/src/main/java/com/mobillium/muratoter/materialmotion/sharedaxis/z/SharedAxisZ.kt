package com.mobillium.muratoter.materialmotion.sharedaxis.z

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mobillium.muratoter.materialmotion.databinding.ActivitySharedAxisZBinding

class SharedAxisZ : AppCompatActivity() {

    private lateinit var binding: ActivitySharedAxisZBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySharedAxisZBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

}