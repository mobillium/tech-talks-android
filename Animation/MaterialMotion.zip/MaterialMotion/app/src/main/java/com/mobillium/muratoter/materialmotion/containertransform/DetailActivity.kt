package com.mobillium.muratoter.materialmotion.containertransform

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import com.google.android.material.transition.platform.MaterialContainerTransform
import com.google.android.material.transition.platform.MaterialContainerTransformSharedElementCallback
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.containertransform.ContainerTransformSettings.CONTAINER_TRANSFORM_DURATION
import com.mobillium.muratoter.materialmotion.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        window.requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS) //Enable Activity Transitions. Optionally enable Activity transitions in your theme with <item name=”android:windowActivityTransitions”>true</item>.
        binding = ActivityDetailBinding.inflate(layoutInflater)
        val item = intent.getParcelableExtra<ListItem>("item")
        binding.container.transitionName = item?.id.toString()
        setEnterSharedElementCallback(MaterialContainerTransformSharedElementCallback()) // Attach a callback used to receive the shared elements from Activity A to be used by the container transform transition.
        window.sharedElementEnterTransition = buildContainerTransform()
        window.sharedElementReturnTransition = buildContainerTransform()
        setContentView(binding.root)
        super.onCreate(savedInstanceState)
        binding.content = item
    }

    // Set this Activity’s enter and return transition to a MaterialContainerTransform
    private fun buildContainerTransform() =
        MaterialContainerTransform().apply {
            addTarget(binding.container)
            duration = CONTAINER_TRANSFORM_DURATION
            interpolator = FastOutSlowInInterpolator()
            fadeMode = MaterialContainerTransform.FADE_MODE_IN
        }
}