package com.mobillium.muratoter.materialmotion.sharedaxis.y

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentPlanetBinding

private const val ARG_PLANET_ID = "planet_id"

class PlanetFragment : Fragment() {
    private lateinit var binding: FragmentPlanetBinding

    private var planetId: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            planetId = it.getInt(ARG_PLANET_ID)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_planet, container, false)
        binding.lifecycleOwner = viewLifecycleOwner
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val planet = planets.singleOrNull { it.id == planetId }
        planet?.let {
            binding.planet = it
        }
    }

    companion object {
        /**
         * @param planetId
         * @return A new instance of fragment StepFragment.
         */
        @JvmStatic
        fun newInstance(planetId: Int) =
            PlanetFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_PLANET_ID, planetId)
                }
            }
    }
}