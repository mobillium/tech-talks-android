package com.mobillium.muratoter.materialmotion.containertransform

import android.os.Parcelable
import androidx.annotation.ColorRes
import kotlinx.parcelize.Parcelize

@Parcelize
data class ListItem(
    val id: Long,
    val title: String,
    val desc: String,
    val owner: String,
    @ColorRes val color: Int
) : Parcelable

