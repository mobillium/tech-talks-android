package com.mobillium.muratoter.materialmotion.containertransform

import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.navArgs
import com.google.android.material.transition.MaterialContainerTransform
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentListDetailBinding
import com.mobillium.muratoter.materialmotion.ext.themeColor


class ListDetailFragment : Fragment(R.layout.fragment_list_detail) {
    private lateinit var binding: FragmentListDetailBinding
    private val args: ListDetailFragmentArgs by navArgs()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedElementEnterTransition = MaterialContainerTransform().apply {
            drawingViewId = R.id.nav_host_fragment
            duration = resources.getInteger(R.integer.motion_duration_medium).toLong()
            scrimColor = Color.TRANSPARENT
//            setAllContainerColors(requireContext().getColor(R.color.white))
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentListDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.run {
            content = args.content
        }
    }
}