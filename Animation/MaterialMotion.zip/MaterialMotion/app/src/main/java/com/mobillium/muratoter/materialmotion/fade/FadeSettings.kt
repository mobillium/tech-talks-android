package com.mobillium.muratoter.materialmotion.fade

object FadeSettings {
    const val FADE_DURATION = 500L
}