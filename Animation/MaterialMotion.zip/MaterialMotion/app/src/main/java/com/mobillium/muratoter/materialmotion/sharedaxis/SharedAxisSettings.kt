package com.mobillium.muratoter.materialmotion.sharedaxis

object SharedAxisSettings {
    const val SHARED_AXIS_DURATION = 500L
}