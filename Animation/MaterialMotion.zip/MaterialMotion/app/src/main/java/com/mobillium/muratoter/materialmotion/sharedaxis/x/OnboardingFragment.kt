package com.mobillium.muratoter.materialmotion.sharedaxis.x

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentOnboardingBinding

private const val ARG_TITLE = "title"
private const val ARG_BODY = "body"
private const val ARG_DRAWABLE_RES = "drawableRes"

class OnboardingFragment : Fragment() {
    private var title: String? = null
    private var body: String? = null
    private var drawableRes: Int? = null


    private lateinit var binding: FragmentOnboardingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            title = it.getString(ARG_TITLE)
            body = it.getString(ARG_BODY)
            drawableRes = it.getInt(ARG_DRAWABLE_RES)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentOnboardingBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.titleTextView.text = title
        binding.bodyTextView.text = body
        drawableRes?.let { binding.imageView.setImageResource(it) }
    }


    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param body Parameter 1.
         * @param imageRes Parameter 2.
         * @return A new instance of fragment WalkthroughFragment.
         */
        @JvmStatic
        fun newInstance(title: String, body: String, @DrawableRes imageRes: Int) =
            OnboardingFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_TITLE, title)
                    putString(ARG_BODY, body)
                    putInt(ARG_DRAWABLE_RES, imageRes)
                }
            }
    }
}