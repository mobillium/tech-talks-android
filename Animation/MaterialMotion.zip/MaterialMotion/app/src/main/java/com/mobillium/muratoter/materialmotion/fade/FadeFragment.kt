package com.mobillium.muratoter.materialmotion.fade

import android.os.Bundle
import android.transition.TransitionManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.transition.platform.MaterialFade

import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentFadeBinding
import com.mobillium.muratoter.materialmotion.fade.FadeSettings.FADE_DURATION

class FadeFragment : Fragment(R.layout.fragment_fade) {
    private lateinit var binding: FragmentFadeBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFadeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnFabAnimation.setOnClickListener {
            val materialFade = MaterialFade().apply {
                duration = FADE_DURATION
            }
            // Begin the transition by changing properties on the start and end views or removing/adding them from the hierarchy.
            TransitionManager.beginDelayedTransition(binding.root, materialFade)
            when (binding.fab.visibility) {
                View.VISIBLE -> binding.fab.visibility = View.GONE
                View.GONE -> binding.fab.visibility = View.VISIBLE
            }
        }

        binding.btnSnackBarAnimation.setOnClickListener {
            val snackbar =
                Snackbar.make(binding.root, "Hello from Snackbar!", Snackbar.LENGTH_SHORT)
            snackbar.animationMode = BaseTransientBottomBar.ANIMATION_MODE_FADE
            snackbar.show()
        }
    }
}