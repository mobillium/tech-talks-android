package com.mobillium.muratoter.materialmotion.containertransform

object ContainerTransformSettings {

    const val CONTAINER_TRANSFORM_DURATION = 500L
}