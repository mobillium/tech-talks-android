package com.mobillium.muratoter.materialmotion.fadethrough

object FadeThroughSettings {
    const val FADE_THROUGH_DURATION = 500L
}