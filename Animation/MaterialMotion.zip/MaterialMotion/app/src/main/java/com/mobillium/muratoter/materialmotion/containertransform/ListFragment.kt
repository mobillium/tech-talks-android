package com.mobillium.muratoter.materialmotion.containertransform

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.doOnPreDraw
import androidx.databinding.BindingAdapter
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.transition.MaterialElevationScale
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentListBinding


class ListFragment : Fragment(R.layout.fragment_list), MyListAdapter.ClickListener {
    private lateinit var binding: FragmentListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Postpone enter transitions to allow shared element transitions to run.
        // https://github.com/googlesamples/android-architecture-components/issues/495
        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        initUI()
    }

    override fun onClick(view: View, item: ListItem) {
        exitTransition = MaterialElevationScale(false).apply {
            duration = resources.getInteger(R.integer.motion_duration_medium).toLong()
        }
        reenterTransition = MaterialElevationScale(true).apply {
            duration = resources.getInteger(R.integer.motion_duration_medium).toLong()
        }

        val transitionName = getString(R.string.container_card_detail_transition_name)
        val extras = FragmentNavigatorExtras(view to transitionName)
        val directions = ListFragmentDirections.actionListFragmentToListDetailFragment(item)
        findNavController().navigate(directions, extras)
    }

    private fun initUI() {
        binding.run {
            list = ListStore.allItems
            adapter = MyListAdapter(this@ListFragment)
        }

        binding.btnAdd.setOnClickListener {
            navigateToCreate()
        }
    }


    private fun navigateToCreate() {
        exitTransition = MaterialElevationScale(false).apply {
            duration = resources.getInteger(R.integer.motion_duration_medium).toLong()
        }
        reenterTransition = MaterialElevationScale(true).apply {
            duration = resources.getInteger(R.integer.motion_duration_medium).toLong()
        }

        val directions = ListFragmentDirections.actionListFragmentToAddFragment()
        findNavController().navigate(directions)
    }
}


@BindingAdapter("items", "adapter")
fun <T, VH : RecyclerView.ViewHolder> RecyclerView.items(
    items: List<T>?,
    adapter: ListAdapter<T, VH>
) {

    if (this.adapter != adapter) {
        this.adapter = adapter
    }

    adapter.submitList(items)
}