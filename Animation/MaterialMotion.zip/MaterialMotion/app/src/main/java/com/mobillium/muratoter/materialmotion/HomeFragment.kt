package com.mobillium.muratoter.materialmotion

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.google.android.material.transition.MaterialSharedAxis
import com.mobillium.muratoter.materialmotion.containertransform.ListActivity
import com.mobillium.muratoter.materialmotion.databinding.FragmentHomeBinding
import com.mobillium.muratoter.materialmotion.fadethrough.FadeThroughActivity


class HomeFragment : Fragment(R.layout.fragment_home) {
    private lateinit var binding: FragmentHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        exitTransition = MaterialSharedAxis(MaterialSharedAxis.Y, /* forward= */ true)
        reenterTransition = MaterialSharedAxis(MaterialSharedAxis.X, /* forward= */ false)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initUI()
    }

    private fun initUI() {
        binding.imageView.setGif(R.raw.card1)
        binding.imageView2.setGif(R.raw.card2)
        binding.imageView3.setGif(R.raw.card3)
        binding.imageView4.setGif(R.raw.card1)

        binding.cardContainerTransform.setOnClickListener {
//            val action = HomeFragmentDirections.actionHomeFragmentToListFragment()
//            findNavController().navigate(action)
            startActivity(Intent(requireContext(), ListActivity::class.java))
        }

        binding.cardSharedAxis.setOnClickListener {
            val action = HomeFragmentDirections.actionHomeFragmentToSharedAxisFragment()
            findNavController().navigate(action)
        }

        binding.cardFadeThrough.setOnClickListener {
            startActivity(Intent(requireContext(), FadeThroughActivity::class.java))
        }

        binding.cardFade.setOnClickListener {
            val action = HomeFragmentDirections.actionHomeFragmentToFadeFragment()
            findNavController().navigate(action)
        }
    }
}

private fun ImageView.setGif(drawableRes: Int) {
    Glide.with(this).asGif().load(drawableRes).into(this)
}