package com.mobillium.muratoter.materialmotion.fadethrough

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.transition.MaterialFadeThrough
import com.mobillium.muratoter.materialmotion.R
import com.mobillium.muratoter.materialmotion.databinding.FragmentFadeThroughThreeBinding


class FadeThroughThreeFragment : Fragment(R.layout.fragment_fade_through_three) {
    private lateinit var binding: FragmentFadeThroughThreeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterTransition = MaterialFadeThrough().apply {
            duration = FadeThroughSettings.FADE_THROUGH_DURATION
        }
        exitTransition=MaterialFadeThrough().apply {
            duration = FadeThroughSettings.FADE_THROUGH_DURATION
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFadeThroughThreeBinding.inflate(inflater, container, false)
        binding.apply {
            content = contentThroughThreeItem
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

}

val contentThroughThreeItem = FadeThroughContent(
    "https://is1-ssl.mzstatic.com/image/thumb/Music123/v4/70/5e/fe/705efec8-c546-0534-64fa-77ee0c8fd99d/pr_source.png/1000x1000cc.jpg",
    "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
)